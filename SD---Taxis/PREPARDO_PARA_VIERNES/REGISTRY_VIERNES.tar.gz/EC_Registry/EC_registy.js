// Importamos las dependencias necesarias
const express = require('express');
const mysql = require('mysql');
const https = require('https');
const fs = require('fs');

const app = express();
const PORT = 3000;

// Middleware para analizar el cuerpo de las solicitudes POST en formato JSON
app.use(express.json());

const dbHost = process.argv[2]; // El primer argumento después del nombre del script
if (!dbHost) {
    console.error('Por favor, proporciona la dirección IP de la base de datos como argumento.');
    process.exit(1);
}

// Configuración de la base de datos remota
const db = mysql.createConnection({
    host: 'localhost', // Cambia esto por la URL de tu base de datos remota
    user: 'enrique',         // Usuario de la base de datos
    password: 'passwd',     // Contraseña de la base de datos
    database: 'TAXI' // Nombre de la base de datos
});

// Conexión a la base de datos
db.connect((err) => {
    if (err) {
        console.error('Error conectando a la base de datos:', err);
        process.exit(1);
    }
    console.log('Conectado a la base de datos remota');
});

// Endpoint POST para insertar datos
app.post('/insert', (req, res) => {
    const { id} = req.body; // Esperamos un id y los datos a insertar en el cuerpo de la solicitud

    if (!id) {
        return res.status(400).json({ message: 'Por favor, proporciona el id' });
    }

    // Aseguramos que el id se incluya en los datos a insertar
    const insertData = { id };

    const sql = `INSERT INTO Taxi (id, posx, posy, estado) VALUES (?, 1, 1, 'ND')`;

    db.query(sql, [id], (err, result) => {
        if (err) {
            console.error('Error ejecutando la consulta:', err);
            return res.status(500).json({ message: 'Error al insertar los datos en la base de datos.' });
        }
        res.status(200).json({ message: 'Datos insertados correctamente', result });
    });
});

app.get('/tokens', (req, res) => {
    const sql = 'SELECT id,token FROM Taxi';

    db.query(sql, (err, result) => {
        if (err) {
            console.error('Error ejecutando la consulta:', err);
            return res.status(500).json({ message: 'Error al obtener los datos de la base de datos.' });
        }
        res.status(200).json({ result });
    });
});
app.get('/cifrado', (req, res) => {
    const sql = 'SELECT id,cifrado FROM Taxi';

    db.query(sql, (err, result) => {
        if (err) {
            console.error('Error ejecutando la consulta:', err);
            return res.status(500).json({ message: 'Error al obtener los datos de la base de datos.' });
        }
        res.status(200).json({ result });
    });
});
// Configuración de HTTPS con certificados
const options = {
    key: fs.readFileSync("Registry_KEY.pem"), // Ruta al archivo de clave privada
    cert: fs.readFileSync("Registry.pem") // Ruta al archivo de certificado
};

// Inicia el servidor HTTPS
https.createServer(options, app).listen(PORT, () => {
    console.log(`Servidor corriendo de forma segura en https://localhost:${PORT}`);
});
