window.onload = function () {
    fetch('https://localhost:4000/')  // Asegúrate de que la URL sea HTTPS
        .then(response => {
            console.log('Respuesta del servidor:', response);  // Verifica qué estás recibiendo
            return response.json();  // Obtener los datos en formato JSON
        })
        .then(data => {
            console.log("Datos recibidos desde la API:", data);

            const tableBody = document.getElementById("taxiTable").getElementsByTagName("tbody")[0];
            if (data.length > 0) {
                data.forEach(item => {
                    let row = tableBody.insertRow();
                    row.innerHTML = `
                        <td>${item.id}</td>
                        <td>${item.posx}</td>
                        <td>${item.posy}</td>
                        <td>${item.estado}</td>
                        <td>${item.destino1 || "No asignado"}</td>
                        <td>${item.destino2 || "No asignado"}</td>
                        <td>${item.pasajero || "No asignado"}</td>
                    `;
                });
            } else {
                console.log("No se encontraron datos.");
            }
        })
        .catch(error => {
            console.error("Error al obtener los datos:", error);
        });
};
