const https = require("https");
const express = require("express");
const fs = require("fs");
const socketIO = require("socket.io");
const bodyParser = require("body-parser");
const mysql = require("mysql");
const filePath = './mapa.txt';
// Definir el puerto
const port = 4000;

// Crear instancia de Express
const appSD = express();
appSD.use(bodyParser.json());

let mensajes = [];
const db = mysql.createConnection({
    host: "localhost",
    user: "enrique",
    password: "passwd", // Cambia esto según tu configuración
    database: "TAXI",
});

appSD.post("/send_message", (req, res) => {
    const message = req.body.message;
    console.log("Mensaje recibido:", message);
    // Simula un procesamiento o envío del mensaje
    if (message) {
        mensajes.push(message);
      res.json({ status: 'success', message: `Mensaje LLEGADO DE PUTA MADRE: ${message}` });
    } else {
      res.status(400).json({ error: 'No se recibió un mensaje' });
    }
});

appSD.get("/get_messages", (req, res) => {
    res.json(mensajes);
});

const server =https.createServer({
    key: fs.readFileSync("API_HTTPS_KEY.pem"), // Cambia a tu archivo de clave privada
    cert: fs.readFileSync("API_HTTPS.pem"), // Cambia a tu archivo de certificado
}, appSD);



appSD.get("/api/clientes", (req, res) => {
    db.query("SELECT * FROM Cliente", (err, results) => {
        if (err) {
            console.error("Error al obtener datos de clientes:", err);
            res.status(500).send("Error al obtener datos de clientes.");
        } else {
            res.json(results); // Enviar los resultados como JSON
        }
    });
});

appSD.get("/api/ubicaciones", (req, res) => {
    fs.readFile(filePath, "utf8", (err, data) => {
        if (err) {
            console.error("Error al leer el archivo de ubicaciones:", err);
            res.status(500).send("Error al leer el archivo.");
            return;
        }

        // Procesar el archivo y devolver los datos como JSON
        const locations = data
            .split("\n")
            .filter(line => line.trim() !== "") // Elimina líneas vacías
            .map(line => {
                const [name, posx, posy] = line.split(",");
                return { name, posx: parseInt(posx, 10), posy: parseInt(posy, 10) };
            });

        res.json(locations); // Enviar las ubicaciones como respuesta JSON
    });
});

appSD.get("/api/taxis", (req, res) => {
    db.query("SELECT * FROM Taxi", (err, results) => {
        if (err) {
            console.error("Error al obtener datos:", err);
            res.status(500).send("Error al obtener datos.");
        } else {
            res.json(results); // Enviar los resultados como JSON
        }
    });
});

appSD.get("/", (req, res) => {
    res.send(`
        <!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            
            <style>
                table { width: 45%; border-collapse: collapse; margin: 10px; float: left; font-size: 12px; }
                table, th, td { border: 1px solid black; }
                th, td { padding: 4px; text-align: left; font-size: 12px; }
                th { background-color: #f2f2f2; }
                .container { display: flex; }
                .container > div { margin-right: 20px; }
                .taxiRUN {
                    background-color: green;
                    color: green;
                    font-weight: bold;
                    text-align: center;
                }
                #messageContainer {
                    margin-top: 20px;
                    width: 100%;
                }
                #messageList {
                list-style-type: none; /* Quitar los puntos de lista */
                padding: 10px;
                margin: 0;
                max-height: 200px; /* Establecer una altura máxima */
                overflow-y: auto; /* Habilitar desplazamiento vertical si el contenido es demasiado grande */
                border: 1px solid #ddd; /* Borde alrededor del contenedor */
                background-color: #f9f9f9; /* Fondo claro para la lista */
                }
                .message-item {
                    font-size: 12px; /* Tamaño pequeño para los mensajes */
                    line-height: 1.5; /* Mejora la legibilidad */
                    padding: 8px; /* Espaciado interno del mensaje */
                    margin-bottom: 8px; /* Separación entre los mensajes */
                    background-color: #e9e9e9; /* Fondo suave para resaltar cada mensaje */
                    border-radius: 4px; /* Bordes redondeados para un estilo moderno */
                    color: #333; /* Color del texto */
                    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1); /* Sombra ligera para dar profundidad */
                }

                .message-item:hover {
                background-color: #d1e7ff; /* Color de fondo al pasar el ratón */
                }
                .ubicacion {
                    background-color: blue;
                    color: blue;
                    font-weight: bold;
                    text-align: center;
                }
                .taxiSTOP {
                    background-color: red;
                    color: red;
                    font-weight: bold;
                    text-align: center;
                }
                .cliente {
                    background-color: black;
                    color: yellow;
                    font-weight: bold;
                    text-align: center;
                }
                /* Estilo para el mapa */
                #mapContainer {
                    clear: both;
                    margin-top: 20px;
                    display: flex;
                    justify-content: center;
                    align-items: center;
                }
                #mapTable {
                    border-collapse: collapse;
                    width: 400px; /* Ajusta el tamaño del mapa */
                    height: 400px;
                }
                #mapTable td {
                    width: 5%; /* Para que cada celda sea cuadrada */
                    height: 5%;
                    border: 1px solid #ddd;
                    background-color: #f8f9fa; /* Fondo claro */
                }
            </style>
        </head>
        <body>
            
            <div id="messageContainer">
                
                <ul id="messageList">
                    <!-- Los mensajes se agregarán aquí dinámicamente -->
                </ul>
            </div>
            

            </div>
            <div class="container">
                <!-- Tabla de Taxis -->
                <div>
                    <h2>Tabla de Taxis 🚕</h2>
                    <table id="taxiTable">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Posición X</th>
                                <th>Posición Y</th>
                                <th>Estado</th>
                                <th>Destino 1</th>
                                <th>Destino 2</th>
                                <th>Pasajero</th>
                            </tr>
                        </thead>
                        <tbody id="taxiTableBody">
                            <!-- Los datos de los taxis serán insertados aquí -->
                        </tbody>
                    </table>
                </div>

                <!-- Tabla de Clientes -->
                <div>
                    <h2>Tabla de Clientes🧑‍🎄</h2>
                    <table id="clienteTable">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Posición X</th>
                                <th>Posición Y</th>
                                <th>Destino</th>
                                <th>Estado</th>
                            </tr>
                        </thead>
                        <tbody id="clienteTableBody">
                            <!-- Los datos de los clientes serán insertados aquí -->
                        </tbody>
                    </table>
                </div>
            </div>

            <!-- Contenedor para el mapa -->
            <div id="mapContainer">
                
                <table id="mapTable">
                    <!-- Las filas y columnas del mapa se generarán dinámicamente -->
                </table>
            </div>

            <script>
                
                async function loadMessages() {
                    try {
                        const response = await fetch('https://localhost:4000/get_messages');
                        const messages = await response.json();
                    
                        const messageList = document.getElementById('messageList');
                        messageList.innerHTML = '';  // Limpiar los mensajes previos

                        // Mostrar los mensajes en la lista
                        messages.forEach(msg => {
                            const listItem = document.createElement('li');
                            listItem.className = 'message-item';  // Asignar la clase de estilo
                            listItem.textContent = msg;  // Mostrar el mensaje
                            messageList.appendChild(listItem);
                        });
                        messageList.scrollTop = messageList.scrollHeight;  // Desplazar hacia abajo
                    
                    } catch (error) {
                        console.error('Error al cargar los mensajes:', error);
                    }

                }

                function generateMap() {
                    const mapTable = document.getElementById("mapTable");
    
                    // Limpiar cualquier contenido previo en el mapa
                    mapTable.innerHTML = '';
                    
                    // Crear la fila para el eje X (nombres de las columnas)
                    const headerRow = document.createElement("tr");
                    const blankCell = document.createElement("td"); // Espacio vacío para la intersección
                    headerRow.appendChild(blankCell);

                    // Crear las celdas de la fila de los ejes X
                    for (let i = 1; i <= 20; i++) {
                        const headerCell = document.createElement("td");
                        headerCell.textContent = i;
                        headerRow.appendChild(headerCell);
                    }
                    mapTable.appendChild(headerRow);
                    
                    // Crear las filas para el mapa con la columna del eje Y
                    for (let i = 1; i <= 20; i++) { // Filas (eje Y)
                        const row = document.createElement("tr");
                        
                        // Crear la celda para el número del eje Y
                        const rowLabel = document.createElement("td");
                        rowLabel.textContent = i;
                        row.appendChild(rowLabel);

                        // Crear las celdas del mapa
                        for (let j = 1; j <= 20; j++) { // Columnas (eje X)
                            const cell = document.createElement("td");
                            row.appendChild(cell);
                        }
                        
                        mapTable.appendChild(row);
                    }
                    updateMap();
                }
                function updateMap() {
                    const passengers = [];
                    for (let i = 1; i < 21; i++) {
                    for (let j = 1; j < 21; j++) {
                        const cell = mapTable.rows[i].cells[j];
                        cell.textContent = ""; // Limpiar el contenido de la celda
                        cell.className = "";   // Resetear las clases de la celda
                    }
                    }
                    fetch("/api/taxis")
                        .then(response => response.json())
                        .then(data => {
                            const mapTable = document.getElementById("mapTable");
                            
                            data.forEach(taxi => {
                                
                                
                                const cell = mapTable.rows[taxi.posx].cells[taxi.posy];
                                cell.textContent = taxi.id; // Marcar la posición del taxi
                                if (taxi.pasajero != null) {
                                    
                                    passengers.push(taxi.pasajero);
                                    
                                    cell.textContent += taxi.pasajero;
                                }
                                if (taxi.estado == "RUN") {
                                    cell.className = "taxiRUN"; // Estilo para taxis en movimiento
                                }
                                if (taxi.estado == "OK") {
                                    cell.className = "taxiRUN"; // Estilo para taxis en movimiento
                                }  
                                if (taxi.estado == "KO") {
                                    cell.textContent += "!"; // Estilo para taxis detenidos
                                    cell.className = "taxiSTOP";
                                }
                                if (taxi.estado == "OKP") {
                                    cell.className = "taxiSTOP";
                                }   

                                
                                
                            });
                        })
                        .catch(error => {
                            console.error("Error al actualizar el mapa:", error);
                        });
                    
                    fetch("/api/clientes")
                        .then(response => response.json())
                        .then(data => {
                            const mapTable = document.getElementById("mapTable");
                            
                            data.forEach(cliente => {
                                const cell = mapTable.rows[cliente.posx].cells[cliente.posy];
                                
                                if (cliente.estado == "OK") {
                                    cell.textContent = cliente.id; // Marcar la posición del cliente
                                    cell.className = "cliente"; // Estilo para los clientes
                                }
                                
                                
                                
                            });
                        })
                        .catch(error => {
                            console.error("Error al actualizar el mapa:", error);
                        });
                    fetch("/api/ubicaciones")
                        .then(response => response.json())
                        .then(data => {
                            const mapTable = document.getElementById("mapTable");
                            
                            data.forEach(ubicacion => {
                                const cell = mapTable.rows[ubicacion.posx].cells[ubicacion.posy];
                                cell.textContent = ubicacion.name; // Marcar la posición de la ubicación
                                cell.className = "ubicacion"; // Estilo para las ubicaciones
                            });
                        })
                        .catch(error => {
                            console.error("Error al actualizar el mapa:", error);
                        });
                }
                // Llamar a la función para generar el mapa al cargar la página
                window.onload = () => {
                    generateMap();
                    loadTaxiData();
                    loadClienteData();
                    loadMessages();
                    
                };

                // Función para cargar los datos de los taxis
                async function loadTaxiData() {
                    try {
                        const response = await fetch("/api/taxis");
                        const data = await response.json();
                        const tbody = document.getElementById("taxiTableBody");
                        tbody.innerHTML = ""; // Limpiar la tabla antes de agregar nuevos datos

                        data.forEach(taxi => {
                            const row = document.createElement("tr");
                            row.innerHTML = \`
                                <td>\${taxi.id}</td>
                                <td>\${taxi.posx}</td>
                                <td>\${taxi.posy}</td>
                                <td>\${taxi.estado}</td>
                                <td>\${taxi.destino1 || 'N/A'}</td>
                                <td>\${taxi.destino2 || 'N/A'}</td>
                                <td>\${taxi.pasajero || 'N/A'}</td>
                            \`;
                            tbody.appendChild(row);
                        });
                        
                    } catch (error) {
                        console.error('Error al cargar los datos de taxis:', error);
                    }
                }

                // Función para cargar los datos de los clientes
                async function loadClienteData() {
                    try {
                        const response = await fetch("/api/clientes");
                        const data = await response.json();
                        const tbody = document.getElementById("clienteTableBody");
                        tbody.innerHTML = ""; // Limpiar la tabla antes de agregar nuevos datos

                        data.forEach(cliente => {
                            const row = document.createElement("tr");
                            row.innerHTML = \`
                                <td>\${cliente.id}</td>
                                <td>\${cliente.posx}</td>
                                <td>\${cliente.posy}</td>
                                <td>\${cliente.destino || 'N/A'}</td>
                                <td>\${cliente.estado || 'N/A'}</td>
                            \`;
                            tbody.appendChild(row);
                        });
                        
                    } catch (error) {
                        console.error('Error al cargar los datos de clientes:', error);
                    }
                }

                // Opcional: Actualizar los datos cada 1 segundo
                setInterval(loadTaxiData, 2000);
                setInterval(loadClienteData, 2000);
                setInterval(updateMap, 2000);
                setInterval(loadMessages, 1000);
            </script>
        </body>
        </html>
    `);
});





// Configurar HTTPS con el certificado y clave privada

server.listen(port, () => {        
    console.log(`Servidor HTTPS corriendo en https://localhost:${port}`);
    
});

